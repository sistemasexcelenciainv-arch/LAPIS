﻿# Lector-de-imagen-..
